
public interface Robot {
    /**
     * Gets a position around the robot position.
     * If the robot can move to the random position then move the robot.
     */
    public void move();

    /**
     * Get the position of the robot.
     * @return pos position of the robot.
     */
    public Position getPos();

    /**
     * Set the position for the robot.
     * @param pos Position to set the robot to.
     */
    public void setPos(Position pos);

    /**
     * Check if the robot have reached the goal.
     * @return true or false.
     */
    public boolean ReachedGoal();

    /**
     * Gets the tosring from maze and puts the robot on it's position in the maze.
     * Uses to print the maze.
     * @return string that the program can print.
     */
    @Override
    public String toString();
}
